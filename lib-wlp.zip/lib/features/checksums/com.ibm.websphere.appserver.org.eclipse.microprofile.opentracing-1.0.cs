#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.opentracing-1.0.mf=bfe6036a2e9d6dd164916f24a98c1059
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.opentracing.1.0_1.0.27.jar=2f0c0220beb96b725227d65d5c0c3af4
