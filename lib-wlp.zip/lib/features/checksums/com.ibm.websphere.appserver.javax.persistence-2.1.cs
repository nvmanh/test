#Wed May 08 08:08:55 JST 2019
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.27.jar=791d9f0ac79daedd0554c3acd8bd353a
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=2936cc422cbc90fe25ecb74fb24e5db6
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.27.jar=04962ddacee4390bcf7fc238c8611493
