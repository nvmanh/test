#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.microprofile.faulttolerance.cdi_1.0.27.jar=2295df76f3ded7fd061a0e833eb482b3
lib/features/com.ibm.websphere.appserver.mpFaultTolerance1.0-cdi1.2.mf=845743695810bbe5dd491917461e0145
lib/com.ibm.ws.microprofile.faulttolerance.cdi.1.0.services_1.0.27.jar=61c45e0aacd51b40a48ed9d4c33a63e2
