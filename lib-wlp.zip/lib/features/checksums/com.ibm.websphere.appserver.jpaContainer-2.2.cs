#Fri Apr 19 09:41:46 BST 2019
lib/com.ibm.ws.jpa.container.v22_1.0.27.jar=74fe0b5fca3712c4d7d0b9e3bdfe4301
lib/com.ibm.ws.jpa.container.thirdparty_1.0.27.jar=6c9516808b643c4ad2b420aeb46ffcd2
lib/com.ibm.ws.jpa.container_1.0.27.jar=eaa29582025947369b29ca6189fdd1f1
lib/features/com.ibm.websphere.appserver.jpaContainer-2.2.mf=302b04d117291a8097a9e915cce6f872
