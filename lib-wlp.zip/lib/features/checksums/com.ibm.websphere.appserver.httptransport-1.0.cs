#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.httptransport-1.0.mf=e4c2e13a6f8ee970ce9f2281e3c01bc8
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.httptransport_4.1-javadoc.zip=ec04c49ea67ecbb38908385b4878d02d
lib/com.ibm.ws.transport.http_1.0.27.jar=b5c8d6e6f04669e12189927710c47014
dev/spi/ibm/com.ibm.websphere.appserver.spi.httptransport_4.1.27.jar=705f93072680833d5ada7282e2c675cb
