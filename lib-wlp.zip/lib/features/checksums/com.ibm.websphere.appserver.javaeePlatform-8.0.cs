#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.javaee.version_1.0.27.jar=9b10b265513359a76eee93a24cfe284d
lib/features/com.ibm.websphere.appserver.javaeePlatform-8.0.mf=238fd92292e25e6280d7c40005da3e6b
lib/com.ibm.ws.javaee.platform.v8_1.0.27.jar=0b7314f84f0e75196bb99f50e9c80768
