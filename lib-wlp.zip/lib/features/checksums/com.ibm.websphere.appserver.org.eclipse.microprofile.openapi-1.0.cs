#Fri Apr 19 09:41:44 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.0_1.0.27.jar=74a3d97913cb3bf90b251e528b98851e
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.0.mf=0b95041c0d11de98c06bb15e829449fd
