#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.appLifecycle-1.0.mf=2a3646af82ee8d42f17f581544c624c0
lib/com.ibm.ws.app.manager.lifecycle_1.0.27.jar=d1596e7b94ee79d2d3fa1b462cdf1655
