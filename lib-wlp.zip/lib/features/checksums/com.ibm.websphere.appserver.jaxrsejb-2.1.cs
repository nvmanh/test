#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.27.jar=7a3a7f098529eee648ffa8f9f92f8fe2
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.1.mf=f7476526fe85275086365b8c13c4d07c
