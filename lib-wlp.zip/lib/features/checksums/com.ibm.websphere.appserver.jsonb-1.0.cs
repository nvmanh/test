#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.jsonb.service_1.0.27.jar=fc040556bf546fcdafed31b9eac318c2
lib/features/com.ibm.websphere.appserver.jsonb-1.0.mf=8c86a4fbf7317a22d10723ffbf2e2c99
