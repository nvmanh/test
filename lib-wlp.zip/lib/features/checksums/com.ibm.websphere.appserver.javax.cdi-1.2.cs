#Fri Apr 19 09:41:46 BST 2019
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.27.jar=9ce9d3481275513fc38895bd25ff2382
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=7af369b1dbaa7706b162ab9d0cf38877
