#Fri Apr 19 09:41:44 BST 2019
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.27.jar=256186f65a438c58b6834c1b4366b87d
lib/com.ibm.websphere.rest.api.discovery_1.0.27.jar=29e2f108deb218a63e6c6df25972c45f
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=8f573bfee85e3f5bba56f9bde2b630a7
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=8005c2e2d49c05e6750a412c2a6e494f
