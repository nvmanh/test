#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.27.jar=5f777387bd7e9bd8a89ee2f081c4397e
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.1.mf=e29137a3f2cf99e7d286ed56cda44619
