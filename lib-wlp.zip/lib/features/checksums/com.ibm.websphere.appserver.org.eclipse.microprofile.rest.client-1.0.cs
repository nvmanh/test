#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.0.mf=135e1b4dd1ff9d8a4420d051c30b6d23
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.0_1.0.27.jar=355369c3ae26a46ce0b52576b9e77843
