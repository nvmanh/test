#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/features/com.ibm.websphere.appserver.mpOpenTracing-1.0.mf=2e3842385a664df7283a9013559ba93b
lib/com.ibm.ws.microprofile.opentracing_1.0.27.jar=495b63990f10bcf5c22ba87c4ce1acb9
