#Fri Apr 19 09:41:46 BST 2019
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.27.jar=33ef9e51dd588ccb296e657b485b2af5
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.1.mf=4dcbdbc549027ff9fd97fa3405ecce38
