#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.session.monitor_1.0.27.jar=b79eb63e3cce2e1262d2296ab3026a60
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.sessionstats_1.0-javadoc.zip=8397931ca6dad7efaca4d16bca2da72c
dev/api/ibm/com.ibm.websphere.appserver.api.sessionstats_1.0.27.jar=863b8131de0493438a7c4e1d0e6bd60b
lib/features/com.ibm.websphere.appserver.sessionMonitor-1.0.mf=dd03a4a4df54356b3b450ce981c9ecf3
