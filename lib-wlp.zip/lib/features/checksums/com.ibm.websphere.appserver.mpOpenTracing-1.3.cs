#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/features/com.ibm.websphere.appserver.mpOpenTracing-1.3.mf=e23bb75349663c86f4a735c856c02871
lib/com.ibm.ws.microprofile.opentracing.1.3_1.0.27.jar=b225309fcc901c7d2a2512f88100bf23
