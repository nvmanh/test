#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.27.jar=ef78a4d207174a8a872f0947f72abf9a
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=865805c2e37855462c8bf37289609533
