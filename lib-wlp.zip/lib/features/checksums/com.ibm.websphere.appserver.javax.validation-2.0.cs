#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.validation.2.0_1.0.27.jar=a78aae674ca4202a038e0002595f9d4c
lib/features/com.ibm.websphere.appserver.javax.validation-2.0.mf=847a5e6206929cf12e092c4f418a3bc0
