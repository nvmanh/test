#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=0b6d08616956366554ad355d124db93a
lib/com.ibm.websphere.rest.handler_1.0.27.jar=a4324e2609c8cbafebc3ff5df5aa5448
lib/com.ibm.ws.rest.handler_1.0.27.jar=6935a429db9e1697d34b8c951ee57173
lib/com.ibm.websphere.jsonsupport_1.0.27.jar=c7f93c4bbb12ffd61977a718c800bdd9
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=7cf5a3806ef8e16a1e72b6c51b726703
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.27.jar=5aa235e721cf56bf852a0ab570f5a83d
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.27.jar=6bf53c167f089cf9eb85be5b6cb2c616
