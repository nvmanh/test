#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.microprofile.metrics.1.1.cdi_1.0.27.jar=15cd1f0413e9871fe1eb19e4af409eeb
lib/features/com.ibm.websphere.appserver.mpMetrics1.1-cdi1.2.mf=df6b75725cb2af144d118955d89ce57a
