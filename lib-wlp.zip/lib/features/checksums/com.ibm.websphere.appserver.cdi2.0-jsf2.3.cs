#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.cdi.2.0.jsf_1.0.27.jar=9e6d7ab11e3ca2a26fa166f67d2614d0
lib/features/com.ibm.websphere.appserver.cdi2.0-jsf2.3.mf=a991a72ba5e6aa13b35f5b32dfd88e91
