#Fri Apr 19 09:41:46 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.1.1_1.0.27.jar=8ee905461cc948fed0e35bb63688924b
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.1.mf=127879c19f9550d9384568404514c5dc
