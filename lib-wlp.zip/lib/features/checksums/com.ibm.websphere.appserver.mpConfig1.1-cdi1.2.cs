#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.microprofile.config.1.1.cdi.services_1.0.27.jar=ee45a381c7575ccfcf12d218675af47f
lib/com.ibm.ws.microprofile.config.1.1.cdi_1.0.27.jar=1b40b7e31c5ddf1b8be77638d8f78688
lib/features/com.ibm.websphere.appserver.mpConfig1.1-cdi1.2.mf=32d4f51157f1f17709168636ddf64889
