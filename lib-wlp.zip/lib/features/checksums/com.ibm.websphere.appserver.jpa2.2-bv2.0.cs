#Fri Apr 19 09:41:46 BST 2019
lib/com.ibm.ws.jpa.container.beanvalidation.2.0_1.0.27.jar=5efad3a0ca9d6758ae37e1c8a6dee046
lib/features/com.ibm.websphere.appserver.jpa2.2-bv2.0.mf=69616162cc26e009da702352a876550c
