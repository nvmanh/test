#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.jndi.url.contexts_1.0.27.jar=59b5e8aee7e63fe7f0d355778ec10223
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.27.jar=c91e59ef5e971f9430f470a728305729
lib/com.ibm.ws.jndi_1.0.27.jar=4da6f0eb3576661f67a2e450448e45c5
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=fa51047b7f4f80d64678a5c5bf6b0b81
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.27.jar=38d6df0327d39e8a774f5c506253d936
