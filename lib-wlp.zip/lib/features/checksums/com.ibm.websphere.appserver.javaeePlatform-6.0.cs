#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.javaeePlatform-6.0.mf=9c6d02fe5dac9a3e728d7f6e87dbe2c1
lib/com.ibm.ws.security.java2sec_1.0.27.jar=f08f53d5b4b2f5f80a0248d42ad039d4
lib/com.ibm.ws.app.manager.module_1.0.27.jar=a0926b7d79d17b3410fdbe22b6e06fcd
lib/com.ibm.ws.javaee.version_1.0.27.jar=9b10b265513359a76eee93a24cfe284d
