#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.javaee.platform.v7_1.0.27.jar=b1d9d23f12ca86e06bfffb155abc05e7
lib/com.ibm.ws.javaee.platform.defaultresource_1.0.27.jar=6ca96a5e643a0c5a017f698e0262ca34
lib/com.ibm.ws.javaee.version_1.0.27.jar=9b10b265513359a76eee93a24cfe284d
lib/features/com.ibm.websphere.appserver.javaeePlatform-7.0.mf=6c31a9b204243321671d0a6360818c5b
