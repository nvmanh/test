#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=d50af01effab336d41fb27e3f57fada4
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.27.jar=5dfd5ed8a601d575ea37a9907f806af7
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.27.jar=b0f04cc4290dac7cf9e69b246e22d118
