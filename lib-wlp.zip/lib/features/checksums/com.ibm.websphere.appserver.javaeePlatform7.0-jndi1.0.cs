#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.27.jar=57453b01c74e1efaa5673e4d61e82fe8
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=3d90f844ce9d09cefd20749c0be4fb58
