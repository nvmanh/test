#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.opentracing-1.3.mf=b7aed75c00aaa7668f0918f9ae86345e
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.opentracing.1.3_1.0.27.jar=2afb03037cb1d8a572e762f0e55cda59
