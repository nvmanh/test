#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.opentracing-1.1.mf=3317eb9bf3c83aa1d130f69ba607cf54
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.opentracing.1.1_1.0.27.jar=8ff4d45577b94364ce1bbad83eecf88d
