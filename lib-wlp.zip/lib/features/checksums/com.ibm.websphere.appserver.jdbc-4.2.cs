#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.jdbc.4.2.feature_1.0.27.jar=c7e0cbeb5649fe725beb9dac705dd5c7
lib/com.ibm.ws.jdbc.4.2_1.0.27.jar=1ac4df98410281e459fef72638e9def6
lib/features/com.ibm.websphere.appserver.jdbc-4.2.mf=0cc3d65120769b5666dcde4c67856ec6
lib/com.ibm.ws.jdbc.4.1_1.0.27.jar=f9b67d323efc7f6188b7c45ee7d57415
lib/com.ibm.ws.jdbc_1.0.27.jar=41f4d49dd2fd6c68814d8836b2c2900c
