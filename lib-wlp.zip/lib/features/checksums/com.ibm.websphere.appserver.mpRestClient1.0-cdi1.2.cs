#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=d45b034b171b519aa85df3b6e313dac1
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.27.jar=6876aa37643b9fb591c250e1a12faf88
