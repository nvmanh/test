#Fri Apr 19 09:41:45 BST 2019
dev/spi/ibm/com.ibm.websphere.appserver.spi.collectivePlugins_2.0.27.jar=3b48ed6a86e8e74751af076f8d68bfc0
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.collectivePlugins_2.0-javadoc.zip=1d79105507ef6ba69e87a03366c78faf
lib/features/com.ibm.websphere.appserver.autoRestHandlerCollectivePlugins-1.0.mf=c75dca1fd522fdd2713f6f050dcdee14
lib/com.ibm.websphere.collective.plugins_1.0.27.jar=850343fa4db587d6633c8d48c4cef726
