#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.security.common.jsonwebkey_1.0.27.jar=97e6d6de7dc459dda64c64e95a3b5461
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.27.jar=5dfd5ed8a601d575ea37a9907f806af7
dev/api/ibm/com.ibm.websphere.appserver.api.jwt_1.1.27.jar=e959f1ca2ae7a46b8891f6a0becbddfe
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.27.jar=ef3802ea24152a71d926134a582fb1fe
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.27.jar=b0f04cc4290dac7cf9e69b246e22d118
lib/com.ibm.ws.security.common_1.0.27.jar=ab75a0a2a123319c925e4544b1ef3c0b
lib/com.ibm.ws.com.google.gson.2.2.4_1.0.27.jar=abf908435031e2a00f639197bb3ac60f
lib/features/com.ibm.websphere.appserver.jwt-1.0.mf=9ff7d5f2004ade3a68ee83b634cd739c
lib/com.ibm.json4j_1.0.27.jar=a3ffb21671d2f26fbe399cf235660a3a
lib/com.ibm.ws.org.jose4j_1.0.27.jar=70d44af4bcc4f9ec2e2b463941d9a9a0
lib/com.ibm.ws.security.jwt_1.0.27.jar=21efba2a1a97afbcd7263bbbd567db20
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.27.jar=12f8274e215ebae059e71fdec895c43e
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jwt_1.1-javadoc.zip=9f94a9f03e5eb46175dbe6b223c00dbf
lib/com.ibm.ws.org.apache.httpcomponents_1.0.27.jar=88a2b6de4f8d19735a8e12b915bec974
