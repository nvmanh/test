#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=2f4b0a48fc3daeefb7e5a8d710f1f48c
lib/com.ibm.ws.wsoc.cdi.weld_1.0.27.jar=392194e32188921e7d197334aba08062
