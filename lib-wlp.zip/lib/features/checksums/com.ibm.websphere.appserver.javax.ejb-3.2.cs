#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.27.jar=1902e6cf5463f958ebaec1c9f45ae06c
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=77c715b3fa6efa913e856a7eac8917ea
