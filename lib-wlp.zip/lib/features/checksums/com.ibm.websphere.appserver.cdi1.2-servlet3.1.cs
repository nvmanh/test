#Wed May 08 08:09:19 JST 2019
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.27.jar=ef78a4d207174a8a872f0947f72abf9a
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=201ed3bb85be9d7946ecca6d54865fde
lib/com.ibm.ws.cdi.1.2.web_1.0.27.jar=71d2db74e57a0d73cfc1f8973232cd05
lib/com.ibm.ws.cdi.web_1.0.27.jar=df9e38961031be272597de81be4f1242
