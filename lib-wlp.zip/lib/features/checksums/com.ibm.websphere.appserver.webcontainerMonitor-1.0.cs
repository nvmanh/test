#Fri Apr 19 09:41:46 BST 2019
lib/features/com.ibm.websphere.appserver.webcontainerMonitor-1.0.mf=a42fa5a57a2ada618846c95cb3855523
lib/com.ibm.ws.webcontainer.monitor_1.0.27.jar=80bcf1dab33b2be8e4a875d9fb80acdf
