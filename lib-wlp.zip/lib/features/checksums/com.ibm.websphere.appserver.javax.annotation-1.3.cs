#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.javax.annotation-1.3.mf=a1a2026bb382e77c91be26baba1a9b91
dev/api/spec/com.ibm.websphere.javaee.annotation.1.3_1.0.27.jar=03cc5eeb07273e52247c3545ddf52c8b
