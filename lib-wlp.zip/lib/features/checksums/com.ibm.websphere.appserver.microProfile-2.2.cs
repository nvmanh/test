#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.microProfile-2.2.mf=a5b23d14ee94fb020339b804095b3f99
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
