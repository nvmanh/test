#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.javax.jaxrs-2.1.mf=8c99a468c0ddd9dcecda1e070da7cedc
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.27.jar=9f1ccdd7ded9a8bd4c08d4b1cbe9f35b
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.27.jar=4bc6bb254a168af0ed799610a2741ba4
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.1_1.0.27.jar=866e95a6924a4433f58b89d390b2f964
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=59af35f16951f2bc502114dd91d03f45
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.27.jar=1f15fe3ae21fc04d81a2ed9fd688c5ee
