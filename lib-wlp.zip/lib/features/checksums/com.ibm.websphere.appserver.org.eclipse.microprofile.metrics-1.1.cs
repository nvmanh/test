#Fri Apr 19 09:41:45 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.metrics.1.1.1_1.0.27.jar=d9915e59952f67eb2c4959b4f35dcd11
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.metrics-1.1.mf=89f3e67c27a01a210071f20336eba8ee
