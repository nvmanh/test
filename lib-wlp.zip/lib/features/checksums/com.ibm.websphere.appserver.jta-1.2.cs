#Fri Apr 19 09:41:45 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=37dcf7eec335c657333801921f00beb6
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.27.jar=181d761512f32bf981807ca72d4adacc
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.27.jar=29f8c8341dda00ed170f224ff3c58051
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=c297c7d810af2cd4dc46cc8f61577609
