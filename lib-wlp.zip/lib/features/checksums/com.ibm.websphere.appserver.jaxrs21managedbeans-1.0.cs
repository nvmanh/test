#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.jaxrs21managedbeans-1.0.mf=6e71facd0f20cf3197437186a471a9a3
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.27.jar=efece957da4fc02c56475c0d5ac999d3
