#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.cdi.transaction_1.0.27.jar=c03a4f95e2620fbb29e6358f7db06504
lib/features/com.ibm.websphere.appserver.cdi2.0-transaction1.2.mf=6f90a5a4c5b2862f4c37b873c578ba3f
