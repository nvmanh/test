#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.microprofile.health_1.0.27.jar=a4ce55e903630ca0f6de0c7e58a63ef1
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/com.ibm.ws.classloader.context_1.0.27.jar=f569a143034c20e7f2832403817d7260
lib/features/com.ibm.websphere.appserver.mpHealth-1.0.mf=b34e6f96083c35f405687e4673d9c8ee
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.health.1.0_1.0.27.jar=5abcf264298c9f2b08b81c59d74ec783
lib/com.ibm.websphere.jsonsupport_1.0.27.jar=c7f93c4bbb12ffd61977a718c800bdd9
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.27.jar=5aa235e721cf56bf852a0ab570f5a83d
