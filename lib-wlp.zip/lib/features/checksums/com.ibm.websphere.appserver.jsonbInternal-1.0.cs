#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.jsonbInternal-1.0.mf=198d5ea54aee77489f8a2c08dd11c559
