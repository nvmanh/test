#Fri Apr 19 09:41:46 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/com.ibm.ws.microprofile.opentracing.1.2_1.0.27.jar=0de423544ade5832485b59a380fd0c9a
lib/features/com.ibm.websphere.appserver.mpOpenTracing-1.2.mf=a3ae3f54f27087531cd4f9a37310c39f
