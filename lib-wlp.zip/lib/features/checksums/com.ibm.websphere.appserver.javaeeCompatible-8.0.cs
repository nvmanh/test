#Fri Apr 19 09:41:46 BST 2019
lib/com.ibm.ws.javaee.version_1.0.27.jar=9b10b265513359a76eee93a24cfe284d
lib/features/com.ibm.websphere.appserver.javaeeCompatible-8.0.mf=1a83d31adfe63f1c98cb482b4c63c22b
