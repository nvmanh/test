#Fri Apr 19 09:41:46 BST 2019
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.service.description.3.2_1.0.27.jar=496a7cc84db8d36024b328c0883947e7
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.client.3.2_1.0.27.jar=a32031544b227d344b09b769b4872fe1
lib/com.ibm.ws.org.apache.cxf.cxf.rt.frontend.jaxrs.3.2_1.0.27.jar=fbfb180ce11d225b4c0f0af1274161b9
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.27.jar=9f1ccdd7ded9a8bd4c08d4b1cbe9f35b
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.sse.3.2_1.0.27.jar=46e10a667795fb6a2f0ccf47e4ace58e
lib/com.ibm.ws.org.apache.cxf.cxf.tools.wadlto.jaxrs.3.2_1.0.27.jar=bab80d82f592f8fd47445a54a19427a0
dev/api/spec/com.ibm.websphere.javaee.jaxws.2.2_1.0.27.jar=452a274d6eb0b725e6446d780f0ef645
lib/com.ibm.ws.jaxrs.2.1.common_1.0.27.jar=4fe6483b9b9306c1b168f4119f499382
lib/com.ibm.ws.org.apache.cxf.cxf.rt.transports.http.hc.3.2_1.0.27.jar=caa125c3945b19255ab5ba36669e61a5
bin/jaxrs/tools/wadl2java.jar=3f582793bb401ff1e4776f43172c0e34
dev/api/spec/com.ibm.websphere.javaee.jws.1.0_1.0.27.jar=aeb750cb97d1f60d424d929ef6b84651
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.27.jar=7bba3e00a9a124a7d41ca91930d2d279
lib/com.ibm.ws.jaxrs.2.x.config_1.0.27.jar=8db60345c152cf9105562f110895287e
lib/features/com.ibm.websphere.appserver.jaxrs.common-2.1.mf=90945ba460009e491f331660f3860faf
