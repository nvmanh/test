#Fri Apr 19 09:41:45 BST 2019
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.1.27.jar=6a037f071c06f0001a60f0834bbe620c
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.1-javadoc.zip=a2ec8d438ced705a6a5939e012d28398
lib/com.ibm.ws.connectionpool.monitor_1.1.27.jar=bc6bc245df519972132bfbba373ce028
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=0256ba56e18c0a8607241f5ed3b9bc18
