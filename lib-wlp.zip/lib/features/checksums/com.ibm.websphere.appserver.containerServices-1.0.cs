#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.containerServices-1.0.mf=37b1140f55f3d62aee961a181a93e17f
lib/com.ibm.ws.javaee.version_1.0.27.jar=9b10b265513359a76eee93a24cfe284d
lib/com.ibm.ws.container.service_1.0.27.jar=eaecb852e326f7565130098365e0d41d
lib/com.ibm.ws.resource_1.0.27.jar=b8398266c0ae383ce28f6418f3e9f3f8
dev/spi/ibm/com.ibm.websphere.appserver.spi.containerServices_3.0.27.jar=9b5973b137c5ac561b4222c0cf8c42eb
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.containerServices_3.0-javadoc.zip=4f0487a53f34d354bd38059acdbb9594
lib/com.ibm.ws.serialization_1.0.27.jar=c1f5b5c964670ec6cf21ebf2f83dc7fd
