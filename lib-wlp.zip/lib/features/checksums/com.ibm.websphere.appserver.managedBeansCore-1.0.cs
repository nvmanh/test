#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.managedBeansCore-1.0.mf=a2668f9ff7e7b4063872508f10dcd3e2
lib/com.ibm.ws.javaee.dd.ejb_1.1.27.jar=35ea0d67029044ec8019b9c5ed413cd9
lib/com.ibm.ws.managedobject_1.0.27.jar=45e145aacdfc9417c1ed0f433b35945e
lib/com.ibm.ws.ejbcontainer_1.0.27.jar=53c6f4891e9fc7cd92a57eb7e480ed14
lib/com.ibm.ws.jaxrpc.stub_1.1.27.jar=51c250fd5f8841022e2940076826d7c4
