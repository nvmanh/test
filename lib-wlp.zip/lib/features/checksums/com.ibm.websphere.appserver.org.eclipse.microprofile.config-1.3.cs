#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.3.mf=1dd79d2ec03b6caf0c162b5db22e0ec8
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.3_1.0.27.jar=32d85ea76b1af43a3b9ae290fecd278a
