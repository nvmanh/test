#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.mpJwt-1.1.mf=b59b2d3a18526e36631dbc5385648b6a
lib/com.ibm.ws.security.mp.jwt.1.1.config_1.0.27.jar=9eb408d5f4d079cba52b1e74521c0a5b
lib/com.ibm.ws.security.mp.jwt_1.0.27.jar=2dad66a8620dbf5c929c0ea473b8eac7
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.27.jar=12f8274e215ebae059e71fdec895c43e
lib/com.ibm.ws.security.mp.jwt.cdi_1.0.27.jar=1cc400093a2a515202b14ad585c1ebb6
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.27.jar=ef3802ea24152a71d926134a582fb1fe
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.jwt.1.0_1.0.27.jar=1cc12f98991f98a32f8e660eab7d6e78
