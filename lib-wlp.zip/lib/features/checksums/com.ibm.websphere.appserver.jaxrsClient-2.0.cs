#Wed May 08 08:09:13 JST 2019
lib/com.ibm.ws.jaxrs.2.0.client_1.0.27.jar=197768e5e32d7c27b3a41325b1e25a98
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=6bbdcba3b196e54300b88d576d50a654
lib/com.ibm.ws.cxf.client_1.0.27.jar=e4e461c5d9bbeea5d548fa6b33b70c9f
