#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=59107595a45157cfe94f3820616f6484
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.27.jar=2e75eec3cffae379b96df77855379ca9
