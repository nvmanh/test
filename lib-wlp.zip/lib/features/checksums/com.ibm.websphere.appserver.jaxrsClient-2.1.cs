#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.cxf.client_1.0.27.jar=e4e461c5d9bbeea5d548fa6b33b70c9f
lib/com.ibm.ws.jaxrs.2.0.client_1.0.27.jar=197768e5e32d7c27b3a41325b1e25a98
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.1.mf=8df8675d716e4efb7f57b136bc782637
