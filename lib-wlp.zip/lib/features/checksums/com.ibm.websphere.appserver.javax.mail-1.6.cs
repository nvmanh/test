#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.com.sun.mail.javax.mail.1.6_1.6.27.jar=0748f866297c82cf07bed311a1df20a8
lib/features/com.ibm.websphere.appserver.javax.mail-1.6.mf=05e200d01c239ec5bccfc93311f32787
