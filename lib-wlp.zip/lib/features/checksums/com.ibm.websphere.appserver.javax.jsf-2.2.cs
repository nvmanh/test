#Wed May 08 08:08:57 JST 2019
dev/api/spec/com.ibm.websphere.javaee.jsf.2.2_1.0.27.jar=4894f60739f80cf933abc085dc6c12c0
lib/features/com.ibm.websphere.appserver.javax.jsf-2.2.mf=2b65e533efbd8063ff1d3b0d90e2e20d
