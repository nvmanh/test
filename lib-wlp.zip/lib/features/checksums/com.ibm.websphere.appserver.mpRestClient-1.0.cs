#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.mp.client.3.2_1.0.27.jar=1fd31ba3cd69f07b8409f2fcb80157fc
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/features/com.ibm.websphere.appserver.mpRestClient-1.0.mf=2c3669377591e85506ea7aa7ff704d4e
