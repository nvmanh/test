#Fri Apr 19 09:41:44 BST 2019
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink.2.7_1.0.27.jar=d1d2981e2851db9cbbb6b32c359327f8
lib/com.ibm.ws.jpa.container.eclipselink_1.0.27.jar=3b1a207ce3f9e880633f9f1e9045210f
lib/features/com.ibm.websphere.appserver.jpa-2.2.mf=3786e945d49919e5cef23e890de947a3
