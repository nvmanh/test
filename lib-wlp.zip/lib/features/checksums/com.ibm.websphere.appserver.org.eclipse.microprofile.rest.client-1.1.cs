#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.1.mf=9ca9d1276e5a479370e7d9e50b9ed868
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.1_1.0.27.jar=7046fea13d9679b579c2dfe2ad773b77
