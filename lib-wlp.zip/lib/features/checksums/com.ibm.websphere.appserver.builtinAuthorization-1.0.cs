#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.builtinAuthorization-1.0.mf=07b6f3a790c719a7819f23e19b48326e
lib/com.ibm.ws.security.authorization.builtin_1.0.27.jar=1e8c2bc84ac80d460309a472526b0ee8
lib/com.ibm.websphere.security_1.1.27.jar=3998ee5a65c3065ca8546f8be76ea77f
lib/com.ibm.ws.security.authorization_1.0.27.jar=43887e2b5275f694761530a15051e189
