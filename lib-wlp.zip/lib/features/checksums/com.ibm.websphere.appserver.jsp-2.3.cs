#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.jsp_1.0.27.jar=4e3816f5cb5812ed9fbf3b9c4a6857e9
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.jsp_1.0-javadoc.zip=125093212f60fd2b5e9cb39130b70e59
dev/api/spec/com.ibm.websphere.javaee.jstl.1.2_1.0.27.jar=965299d8a58e8383657a2c23429a4c5a
dev/api/spec/com.ibm.websphere.javaee.jsp.tld.2.2_1.2.27.jar=5d0225d8e9f651d7ac5f34227cc93400
lib/com.ibm.ws.jsp.jstl.facade_1.0.27.jar=50bf07818d4b6d790ba93415461d7559
lib/com.ibm.ws.jsp.2.3_1.0.27.jar=5776b86bc0b07f8b51fc3c60b8b395dd
lib/com.ibm.ws.org.eclipse.jdt.core.3.10.2.v20160712-0000_1.0.27.jar=2716eaa2afdfc04040093b31da294f40
lib/features/com.ibm.websphere.appserver.jsp-2.3.mf=aad330e678648f50f350995835c3bf00
dev/spi/ibm/com.ibm.websphere.appserver.spi.jsp_1.0.27.jar=0eee6e4f61459b638cc31825dc30c2e2
