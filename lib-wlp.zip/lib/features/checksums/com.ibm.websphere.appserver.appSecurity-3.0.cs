#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.security.authentication.tai_1.0.27.jar=4727e2af4cf0720cd11b22415157d231
dev/spi/ibm/com.ibm.websphere.appserver.spi.jaspic_1.1.27.jar=3e4612cf5990a58c22a3bbd30fc041c9
dev/api/spec/com.ibm.websphere.javaee.security.1.0_1.0.27.jar=597e73250b397ac67e0f182a236937b1
lib/com.ibm.ws.security.jaspic.1.1_1.0.27.jar=9d9f7d58c5431767dd6a9a30b3db8150
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.jaspic_1.1-javadoc.zip=7a10680c7cd287e8e1f65dac996dcb3f
lib/com.ibm.ws.security.javaeesec.cdi_1.0.27.jar=a051d17ffab2684fc472a39517cecb57
dev/api/spec/com.ibm.websphere.javaee.jaspic.1.1_1.0.27.jar=92732d360efd0531529a1c30b07c11e7
lib/features/com.ibm.websphere.appserver.appSecurity-3.0.mf=b6e852fefc93bbfe336f46ef1973f7db
lib/com.ibm.ws.security.javaeesec.1.0_1.0.27.jar=c39c9411fb31d54d08dbb3622d188bb9
