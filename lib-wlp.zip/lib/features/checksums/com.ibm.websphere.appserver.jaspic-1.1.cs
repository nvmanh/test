#Fri Apr 19 09:41:45 BST 2019
dev/spi/ibm/com.ibm.websphere.appserver.spi.jaspic_1.1.27.jar=3e4612cf5990a58c22a3bbd30fc041c9
lib/com.ibm.ws.security.jaspic.1.1_1.0.27.jar=9d9f7d58c5431767dd6a9a30b3db8150
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.jaspic_1.1-javadoc.zip=7a10680c7cd287e8e1f65dac996dcb3f
lib/features/com.ibm.websphere.appserver.jaspic-1.1.mf=395586491ba0690a21e98e9a2b3c3ecb
dev/api/spec/com.ibm.websphere.javaee.jaspic.1.1_1.0.27.jar=92732d360efd0531529a1c30b07c11e7
