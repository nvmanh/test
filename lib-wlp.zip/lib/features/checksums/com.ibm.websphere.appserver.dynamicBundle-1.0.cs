#Fri Apr 19 09:41:46 BST 2019
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=23b0f7fdab75dd7b4e2407dcebd6f670
lib/com.ibm.ws.dynamic.bundle_1.0.27.jar=60dd17df4323516284e18e70a8117b75
