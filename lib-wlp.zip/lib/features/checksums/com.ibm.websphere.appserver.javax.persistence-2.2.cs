#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.javaee.persistence.api.2.2_1.0.27.jar=bb0d69b6f2f2127c6b1d9f6f109e03fe
dev/api/spec/com.ibm.websphere.javaee.persistence.2.2_1.0.27.jar=1d3ee481364e47236d36f983f8e8c76b
lib/features/com.ibm.websphere.appserver.javax.persistence-2.2.mf=f5687a9bf2f321670351fe045bf5e645
