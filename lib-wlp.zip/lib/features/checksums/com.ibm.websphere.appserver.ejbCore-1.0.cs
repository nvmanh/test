#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.ejbCore-1.0.mf=a1f37dbbaeac637786f71d2c1536fbd1
lib/com.ibm.ws.app.manager.war_1.0.27.jar=bcf7af790abd55363150de1c5d31af09
lib/com.ibm.ws.app.manager.ejb_1.0.27.jar=47eb73cc5a462c09ab56d8ae29ed52c2
