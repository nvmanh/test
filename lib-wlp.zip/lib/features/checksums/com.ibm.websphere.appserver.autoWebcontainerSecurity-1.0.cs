#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.autoWebcontainerSecurity-1.0.mf=d82d4fe26f231f885a0150ae26417030
lib/com.ibm.ws.webcontainer.security.provider_1.0.27.jar=65feac4e04ed41f88ac093fcd921a2db
