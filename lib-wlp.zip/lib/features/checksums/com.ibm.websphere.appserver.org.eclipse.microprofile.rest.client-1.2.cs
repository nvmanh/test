#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.2.mf=2fbc266d80dffd6f34c9116f44e06e15
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.2_1.0.27.jar=13217ceb9d3f5ce8bee4a4c36a168392
