#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.anno_1.0.27.jar=80ed304c02f3c97bb3a03ee5dd6c9c97
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.1.27.jar=f11814a982ada090ba8056f4c729fbcc
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=fcee5c8d71bda5c773fab53e4e0bcf11
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.1-javadoc.zip=f5aa71cc5e08b51cb0f947c079721edb
