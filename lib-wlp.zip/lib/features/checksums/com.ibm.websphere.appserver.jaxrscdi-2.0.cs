#Wed May 08 08:09:18 JST 2019
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=3c40d47b689f5ccd1de4376095a2879c
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.27.jar=33ef9e51dd588ccb296e657b485b2af5
