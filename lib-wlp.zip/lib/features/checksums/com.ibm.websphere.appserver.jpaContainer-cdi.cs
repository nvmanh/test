#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.27.jar=868c31306e25763d6170e2934bee33a5
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=512c8ce471244868d399ae21a2ad7e98
