#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.persistence-2.7.mf=9826786062d71e321face4ce1fd7f281
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink.2.7_1.0.27.jar=d1d2981e2851db9cbbb6b32c359327f8
