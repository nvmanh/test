#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.1.mf=fce58fafe613475244dfdddafb45429d
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.1_1.2.27.jar=4368760f193ec2c986cecd599550c5a1
