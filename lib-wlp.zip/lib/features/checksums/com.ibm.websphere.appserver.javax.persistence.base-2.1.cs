#Wed May 08 08:08:55 JST 2019
lib/com.ibm.ws.javaee.persistence.2.1_1.0.27.jar=d432796329f65f879ed710eebb14aa1c
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=654c797edc5106728b0557099f91877a
