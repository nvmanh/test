#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.faulttolerance-1.1.mf=10f538a094a6ee69e037846016fa22a3
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.faulttolerance.1.1_1.0.27.jar=5ce99ff9a7f5ce42b408bebd0383a3b3
