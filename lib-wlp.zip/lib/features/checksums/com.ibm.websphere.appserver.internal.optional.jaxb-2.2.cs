#Fri Apr 19 09:41:46 BST 2019
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.27.jar=4bc6bb254a168af0ed799610a2741ba4
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=68f76cdaf101e40b0f00c4c94dc918ab
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.27.jar=7b748cf4d69288d8d0825731063a0710
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.27.jar=d86636a6030c02d20301701eed10166d
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.27.jar=1f15fe3ae21fc04d81a2ed9fd688c5ee
