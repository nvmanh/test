#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.cdi2.0-jndi1.0.mf=8f77e72b05dc13ad0dbaefb990437961
lib/com.ibm.ws.cdi.jndi_1.0.27.jar=ed7872d240386fdc7a3e52a6b7792b21
