#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.rls.jdbc_1.0.27.jar=a0e7adb9c9f9ff9d2a0125926340218b
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=02d93ae3e943a91e75273b9ea4a5a8fa
lib/com.ibm.ws.transaction_1.0.27.jar=489f810d88c18acce96574a514f511aa
lib/com.ibm.ws.tx.jta.extensions_1.0.27.jar=8296e5eb96e2cdc4a3668497b9304377
lib/com.ibm.ws.recoverylog_1.0.27.jar=b275da26143dbabf54ab24e535cb4e13
lib/features/com.ibm.websphere.appserver.transaction-1.1.mf=1df332ac51b34ad53447f2a1d643dd5d
lib/com.ibm.tx.ltc_1.0.27.jar=859350638e1378471954323528cf3196
lib/com.ibm.tx.jta_1.0.27.jar=5e6a9461ad82ff7685110972018aad23
lib/com.ibm.tx.util_1.0.27.jar=1e8e6b38d3eb4d3651022125934f4881
lib/com.ibm.ws.tx.embeddable_1.0.27.jar=1b81d9d407459cdd779962686711f9c7
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.27.jar=788bfe3c4effa77f8c0bc8aae39e5da0
