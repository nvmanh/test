#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/com.ibm.ws.microprofile.metrics.1.1_1.0.27.jar=8d8c7fd93feba4ca7a935359ff4ca130
lib/com.ibm.ws.microprofile.metrics.private_1.0.27.jar=8acf11e4e520e528e2da080694391dee
lib/com.ibm.ws.microprofile.metrics.public_1.0.27.jar=96af1995d646644362176c4b12b39d82
lib/com.ibm.ws.microprofile.metrics_1.0.27.jar=13ec279861ef5d3616dfc7cb68dd715f
lib/features/com.ibm.websphere.appserver.mpMetrics-1.1.mf=44d605c627349835bf38041d169f5066
