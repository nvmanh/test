#Wed May 08 08:08:33 JST 2019
dev/api/third-party/com.ibm.ws.jaxrs_1.1.27.jar=bd2b836eedbaba2eb2b6bfc3c14d464e
lib/features/com.ibm.websphere.appserver.jaxrsApiStub-1.1.mf=7c896ea947fc20ff5fd02ce1a3d02fbb
