#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.javax.ejb-3.1.mf=43504d23d3f25f8f73fe665c2b314640
dev/api/spec/com.ibm.websphere.javaee.ejb.3.1_1.0.27.jar=566ab91eb9023e8abb52dff2b3cd0f6d
