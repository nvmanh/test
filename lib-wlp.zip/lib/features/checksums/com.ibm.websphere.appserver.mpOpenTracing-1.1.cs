#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/features/com.ibm.websphere.appserver.mpOpenTracing-1.1.mf=68e5ffe5846bcd70b65b9a372d51c978
lib/com.ibm.ws.microprofile.opentracing.1.1_1.0.27.jar=a322a03aa956edcecf50392290f6f5ac
