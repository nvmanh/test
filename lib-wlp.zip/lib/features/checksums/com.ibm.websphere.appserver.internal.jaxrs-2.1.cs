#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.service.description.3.2_1.0.27.jar=496a7cc84db8d36024b328c0883947e7
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.client.3.2_1.0.27.jar=a32031544b227d344b09b769b4872fe1
lib/com.ibm.ws.org.apache.cxf.cxf.rt.frontend.jaxrs.3.2_1.0.27.jar=fbfb180ce11d225b4c0f0af1274161b9
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.27.jar=9f1ccdd7ded9a8bd4c08d4b1cbe9f35b
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.sse.3.2_1.0.27.jar=46e10a667795fb6a2f0ccf47e4ace58e
lib/com.ibm.ws.org.apache.cxf.cxf.tools.wadlto.jaxrs.3.2_1.0.27.jar=bab80d82f592f8fd47445a54a19427a0
lib/com.ibm.ws.jaxrs.2.1.common_1.0.27.jar=4fe6483b9b9306c1b168f4119f499382
lib/com.ibm.ws.org.apache.cxf.cxf.rt.transports.http.hc.3.2_1.0.27.jar=caa125c3945b19255ab5ba36669e61a5
bin/jaxrs/tools/wadl2java.jar=3f582793bb401ff1e4776f43172c0e34
lib/com.ibm.ws.jaxrs.2.0.web_1.0.27.jar=8612b90103231d0c96a12d87545a77d3
lib/features/com.ibm.websphere.appserver.internal.jaxrs-2.1.mf=ed0b357456cc134d99c61e38bd0b4b32
lib/com.ibm.ws.jaxrs.2.0.server_1.0.27.jar=46d9611bb1ccc2c541fd01f8a14b76bf
lib/com.ibm.ws.jaxrs.2.0.client_1.0.27.jar=197768e5e32d7c27b3a41325b1e25a98
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.27.jar=7bba3e00a9a124a7d41ca91930d2d279
lib/com.ibm.ws.jaxrs.2.x.config_1.0.27.jar=8db60345c152cf9105562f110895287e
