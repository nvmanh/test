#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=643ecc75de0107e11549ec5bab8df647
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.27.jar=bef148d534d750a353a164ca97a93c35
