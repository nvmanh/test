#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.1_1.0.27.jar=5bc39a1a06730de35dc42a0371054193
lib/features/com.ibm.websphere.appserver.jsonpImpl-1.1.1.mf=58c72543db9dc7ad1c8661164032eb0a
lib/com.ibm.ws.org.glassfish.json.1.1_1.0.27.jar=dad8467ee44ae2b98de729f402fa67cd
