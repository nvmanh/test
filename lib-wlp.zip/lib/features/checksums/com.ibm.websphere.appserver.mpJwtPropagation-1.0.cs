#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.mpJwtPropagation-1.0.mf=51da554ae87b3feaf8ba24f323ac1559
lib/com.ibm.ws.jaxrs.2.0.client_1.0.27.jar=197768e5e32d7c27b3a41325b1e25a98
lib/com.ibm.ws.security.mp.jwt.propagation_1.0.27.jar=615bdc1a58b28a802a1b704d454ecc4e
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.jwt.1.0_1.0.27.jar=1cc12f98991f98a32f8e660eab7d6e78
