#Fri Apr 19 09:41:44 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=fba38e96fad7ba3d29ec83539b2042c3
lib/com.ibm.json4j_1.0.27.jar=a3ffb21671d2f26fbe399cf235660a3a
lib/features/com.ibm.websphere.appserver.json-1.0.mf=612f3410563159efe3c07036e7e4ddff
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.27.jar=7d371c9329705d009657283cb6ce8d88
