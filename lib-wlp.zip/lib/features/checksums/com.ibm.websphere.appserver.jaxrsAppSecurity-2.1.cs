#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.jaxrs.2.0.security_1.0.27.jar=303166d0ea857096d650e7817ab66653
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.1.mf=c87d2412678a75dea866ee647a050b4e
