#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.httpcommons-1.0.mf=556243e354ded22842f22c30b3ae5ba4
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.27.jar=12f8274e215ebae059e71fdec895c43e
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.27.jar=ef3802ea24152a71d926134a582fb1fe
lib/com.ibm.ws.org.apache.httpcomponents_1.0.27.jar=88a2b6de4f8d19735a8e12b915bec974
