#Fri Apr 19 09:41:45 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.opentracing.1.2_1.0.27.jar=aef044392f61fdfe7a4779f5ad6cfff7
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.opentracing-1.2.mf=1e459573c0c22e4a5309a3c4f1ba6e26
