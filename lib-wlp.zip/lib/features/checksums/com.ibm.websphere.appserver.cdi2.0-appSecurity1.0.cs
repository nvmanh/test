#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.cdi2.0-appSecurity1.0.mf=aa80efed71e8a86a9a8dcd8668e6540c
lib/com.ibm.ws.cdi.security_1.0.27.jar=cfcfd1a37ea83a180ec6e7da11f01366
