#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=6ea1c9430d969a3c68cb74ebdeefc171
lib/com.ibm.ws.ejbcontainer.session_1.0.27.jar=e6d3896131c01abaed168e7cb0f59764
