#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.mpOpenAPI-1.1.mf=84bbe3c6ccef38420d16ec0177d5c187
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/com.ibm.ws.microprofile.openapi.ui_1.0.27.jar=75a45d1513233dfc501bc7ec7991537c
lib/com.ibm.ws.microprofile.openapi.1.1.model_1.0.27.jar=34326aa318e70cb3dc41d304ec7fcae4
lib/com.ibm.ws.com.fasterxml.jackson.2.9.1_1.0.27.jar=072e6d377ab06f6de00972fef81c7bbd
lib/com.ibm.ws.microprofile.openapi_1.0.27.jar=90e57902a25bb166c88bf1d79d85dcae
