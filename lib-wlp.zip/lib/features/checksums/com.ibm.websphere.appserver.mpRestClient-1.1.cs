#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.mpRestClient-1.1.mf=8690755f10fbb1d7fe4419c7b581e3e1
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.mp.client.3.2_1.0.27.jar=1fd31ba3cd69f07b8409f2fcb80157fc
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
