#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.appSecurity-2.0.mf=8058eca9523e9a7e810ed39a92f6a7c4
lib/com.ibm.ws.security.authentication.tai_1.0.27.jar=4727e2af4cf0720cd11b22415157d231
