#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.jsonb.1.0_1.0.27.jar=921478f124fb4d53ce8db55203dc5cbe
lib/features/com.ibm.websphere.appserver.jsonbImpl-1.0.1.mf=fa104fdaa2b7ffe1a47ff6426e03aad3
lib/com.ibm.ws.org.eclipse.yasson.1.0_1.0.27.jar=4c941f7b64b6a60b08e66b16adbf2b7c
