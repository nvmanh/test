#Fri Apr 19 09:41:46 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionmanager_1.1-javadoc.zip=17d5719815efd531e6972e6c3f422edf
lib/com.ibm.ws.jca.cm_1.0.27.jar=9b25c35c2c398df89c831d8870c13069
dev/api/ibm/com.ibm.websphere.appserver.api.connectionmanager_1.1.27.jar=d22fc8f610e82e856694fbae3f6e42b9
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=332dc84012f7bd244a83b77b44681eeb
