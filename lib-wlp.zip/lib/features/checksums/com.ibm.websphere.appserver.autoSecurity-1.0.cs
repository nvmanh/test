#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.autoSecurity-1.0.mf=540eeb5eca0d2f91e843b2d6b1e8d846
dev/api/ibm/com.ibm.websphere.appserver.api.security.spnego_1.0.27.jar=019e7b65cfd1b0b0c1734baf7d3a1e2b
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security.spnego_1.0-javadoc.zip=6cacec56ecddf21773c78559f1c566b8
