#Fri Apr 19 09:41:45 BST 2019
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=3b0b778a121ff7c6c28f9e72afd96488
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=cc078fe6ffad638c280e114dc417919d
lib/com.ibm.ws.managedbeans_1.0.27.jar=9dd7b329a87152dabbfd82877648fc1c
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=788164a7a6ea3fb24bb6106a48a9068b
