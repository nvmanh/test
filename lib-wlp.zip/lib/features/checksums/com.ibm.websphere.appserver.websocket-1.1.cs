#Fri Apr 19 09:41:45 BST 2019
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=516b1d36d06885418fb335cbb76df17b
lib/com.ibm.ws.wsoc.1.1_1.0.27.jar=5e9166444ea10c915e4912ca6894a06e
lib/com.ibm.ws.wsoc_1.0.27.jar=20c979169ac859bbcd808a93814e08f7
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.27.jar=c84fbf163b0c1cdec15703f254dbd23a
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.27.jar=0b61a500c284393a02f8664aae1e92c0
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=de8bde88e6329f4bbf77b8eccdfc990d
