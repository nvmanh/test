#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/features/com.ibm.websphere.appserver.microProfile-2.1.mf=af7e1368e2538e2f1200e814828f5469
