#Wed May 08 08:09:00 JST 2019
lib/com.ibm.ws.cdi.ejb.common_1.0.27.jar=b7c63c46efde0c38aeb960adef9c1927
lib/com.ibm.ws.cdi.1.2.ejb_1.0.27.jar=12e5d329fbcc0668c1b4c02e05c5fc06
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=498fe26964bb93155137ebb1e0e5a864
