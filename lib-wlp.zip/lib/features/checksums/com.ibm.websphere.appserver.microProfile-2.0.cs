#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/features/com.ibm.websphere.appserver.microProfile-2.0.mf=39d8b0ca37525f11a242d0d1a2131b07
