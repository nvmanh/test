#Wed May 08 08:09:04 JST 2019
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.27.jar=590cc501cb23860d5572719cf264eb9e
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=4180629965dae458a22ec8a0b8ab1673
