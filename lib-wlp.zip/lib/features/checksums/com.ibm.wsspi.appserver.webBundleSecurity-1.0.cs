#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.webcontainer.security.feature_1.0.27.jar=b1ebe58bd2c9a1794a6e1a463463c007
lib/com.ibm.ws.security.authentication.tai_1.0.27.jar=4727e2af4cf0720cd11b22415157d231
lib/features/com.ibm.wsspi.appserver.webBundleSecurity-1.0.mf=954b18d203dd99ce62d7b614ff0f14ca
lib/com.ibm.ws.security.authorization.builtin_1.0.27.jar=1e8c2bc84ac80d460309a472526b0ee8
lib/com.ibm.websphere.security_1.1.27.jar=3998ee5a65c3065ca8546f8be76ea77f
lib/com.ibm.ws.webcontainer.security_1.0.27.jar=4fc1aa891540733ca4901a227f79695c
