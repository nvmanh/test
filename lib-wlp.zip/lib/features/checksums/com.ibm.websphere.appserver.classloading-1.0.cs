#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.activity.1.0_1.0.27.jar=04bb8fba5bfe5b500f6b04b4cd5482b5
dev/spi/ibm/com.ibm.websphere.appserver.spi.classloading_1.4.27.jar=50683fbd6a68aecf181ccb0d95315765
lib/com.ibm.ws.classloading_1.1.27.jar=24cc0dd1c1103f91635fa4594e929306
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.classloading_1.4-javadoc.zip=0def75497a44e1bd2123b610ecc1bb18
lib/features/com.ibm.websphere.appserver.classloading-1.0.mf=e0a45d3bc655edd585eedd98fed40af8
