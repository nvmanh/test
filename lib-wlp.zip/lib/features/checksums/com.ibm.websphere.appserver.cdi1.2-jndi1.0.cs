#Wed May 08 08:09:01 JST 2019
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=0964f7b55fe94ae753ff6f7752c58f7c
lib/com.ibm.ws.cdi.jndi_1.0.27.jar=ed7872d240386fdc7a3e52a6b7792b21
