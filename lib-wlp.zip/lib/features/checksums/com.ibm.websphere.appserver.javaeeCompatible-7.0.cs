#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.javaee.version_1.0.27.jar=9b10b265513359a76eee93a24cfe284d
lib/features/com.ibm.websphere.appserver.javaeeCompatible-7.0.mf=2e5a6e5d4e89d1cad1409ad5629c43ab
