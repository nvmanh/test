#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.javaee.persistence.2.2_1.0.27.jar=d18712e798fb5a8e66ae9e5a509beae0
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.2.mf=532b8e9d24a124a8fb7696372c528036
