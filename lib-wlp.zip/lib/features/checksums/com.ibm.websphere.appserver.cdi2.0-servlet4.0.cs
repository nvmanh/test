#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.cdi2.0-servlet4.0.mf=4a8718fdf3be4d96b38f964554f24209
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.27.jar=ef78a4d207174a8a872f0947f72abf9a
lib/com.ibm.ws.cdi.2.0.web_1.0.27.jar=60c9b511628095e4eba4ff83a80c3323
lib/com.ibm.ws.cdi.web_1.0.27.jar=df9e38961031be272597de81be4f1242
