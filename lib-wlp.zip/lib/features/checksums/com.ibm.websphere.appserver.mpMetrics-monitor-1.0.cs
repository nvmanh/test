#Fri Apr 19 09:41:44 BST 2019
lib/com.ibm.ws.microprofile.metrics.monitor_1.0.27.jar=61eb81f253c9c0f890a9c792eacbbb03
lib/features/com.ibm.websphere.appserver.mpMetrics-monitor-1.0.mf=c4faffa8cb1044d15725e5bbf7d74aab
