#Wed May 08 08:08:35 JST 2019
dev/api/spec/com.ibm.websphere.javaee.jsp.2.2_1.0.27.jar=54fde24df7a264f03788b209222adaee
lib/features/com.ibm.websphere.appserver.javax.jsp-2.2.mf=8e28718ea8a2487b79a9a3252065441d
