#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.mpJwt-1.0.mf=72d0a2b4bd786673e29aa8012eb1d26a
lib/com.ibm.ws.security.mp.jwt_1.0.27.jar=2dad66a8620dbf5c929c0ea473b8eac7
lib/com.ibm.ws.security.mp.jwt.cdi_1.0.27.jar=1cc400093a2a515202b14ad585c1ebb6
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.jwt.1.0_1.0.27.jar=1cc12f98991f98a32f8e660eab7d6e78
