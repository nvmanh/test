#Fri Apr 19 09:41:44 BST 2019
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.27.jar=d95db6433ee9b3117241524c8f1fc231
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=37dcf7eec335c657333801921f00beb6
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.27.jar=29f8c8341dda00ed170f224ff3c58051
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=3f78bb1e9321854c7b36b95262454171
