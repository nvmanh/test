#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.autoSecurityS4U2-1.0.mf=d9fb4c169c5198c9dd5d917558d6f29a
lib/com.ibm.ws.security.token.s4u2_1.0.27.jar=e5af87e4c949716d891143abd2a451df
