#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.security-1.0.mf=5017d4224a739ca621d92bf9742d4dcc
lib/com.ibm.ws.management.security_1.0.27.jar=9b630aef455b3bdb896286d266d6b743
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security_1.2-javadoc.zip=92299e296446e3e7fa2345a7698a797c
dev/api/ibm/com.ibm.websphere.appserver.api.security_1.2.27.jar=460c274d6fc7e7016e6e360c33aa7b01
lib/com.ibm.ws.security.quickstart_1.0.27.jar=ef9edbd82fa1918aaa09ef1248e01bd3
lib/com.ibm.websphere.security.impl_1.0.27.jar=b56c737f610fc7bdc2e53429deae7db1
