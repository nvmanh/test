#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.health-1.0.mf=10efb5be17aff67e4ac55fbe921e964b
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.health.1.0_1.0.27.jar=5abcf264298c9f2b08b81c59d74ec783
