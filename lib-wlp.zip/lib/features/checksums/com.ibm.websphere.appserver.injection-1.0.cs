#Fri Apr 19 09:41:46 BST 2019
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=9526e36bbdbd55deacd2b2a0265556ca
lib/com.ibm.ws.injection_1.0.27.jar=543636a3e1418279401c7e7d45c55b7a
