#Wed May 08 08:09:18 JST 2019
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=23b08d6f17f23715a44c5a89830278e5
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.27.jar=7a3a7f098529eee648ffa8f9f92f8fe2
