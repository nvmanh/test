#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.ejbcontainer.jpa_1.0.27.jar=788b7cef440d257cc1eeac96ee414aae
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=bd13cc5e5706787a715720c68ff6e698
