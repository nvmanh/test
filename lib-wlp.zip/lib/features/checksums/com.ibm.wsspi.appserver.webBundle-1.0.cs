#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.eba.wab.integrator_1.0.27.jar=9c7e52e06ba71ce24652ed26c4300197
dev/spi/ibm/com.ibm.websphere.appserver.spi.wab.configure_1.0.27.jar=7637b9ff791eb195f4fb9a0b782a1a37
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.wab.configure_1.0-javadoc.zip=27df3341e938b561c70c5e51ee84a73a
lib/com.ibm.ws.app.manager.wab_1.0.27.jar=a3115b1dde22df1dc23a49fabc556b6a
lib/features/com.ibm.wsspi.appserver.webBundle-1.0.mf=76b38aaec737844b00849b434910dd1c
