#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.cdi.2.0_1.0.27.jar=70f8315cf46fca93700d69ce612a77e6
lib/features/com.ibm.websphere.appserver.javax.cdi-2.0.mf=498c99298b07d8fa3619ea831562bbd9
