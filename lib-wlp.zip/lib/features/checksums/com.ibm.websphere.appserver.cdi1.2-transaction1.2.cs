#Wed May 08 08:09:14 JST 2019
lib/com.ibm.ws.cdi.transaction_1.0.27.jar=c03a4f95e2620fbb29e6358f7db06504
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=704e92b7aa64a9ed3b6174e95c2b3db3
