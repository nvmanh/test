#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-ssl1.0.mf=0a4b6550171bc2102711fe9830535615
lib/com.ibm.ws.microprofile.rest.client.ssl_1.0.27.jar=44521d3520168b373e23534bc27ec6dc
