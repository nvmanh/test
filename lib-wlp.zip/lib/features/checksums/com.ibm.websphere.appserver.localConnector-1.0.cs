#Fri Apr 19 09:41:45 BST 2019
lib/features/com.ibm.websphere.appserver.localConnector-1.0.mf=3d01e387b42b7b861dfc603e0fa0372e
lib/com.ibm.ws.jmx.connector.local_1.0.27.jar=432045b5e02e4e96bebb0988bf99f559
