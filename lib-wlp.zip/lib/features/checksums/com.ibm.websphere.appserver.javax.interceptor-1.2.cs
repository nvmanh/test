#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.2_1.0.27.jar=4d17283d247c757afa68cf293cae0d22
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.2.mf=1d60e48381835d17db7b01251550d126
