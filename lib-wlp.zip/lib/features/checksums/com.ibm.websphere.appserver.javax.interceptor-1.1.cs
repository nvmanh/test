#Fri Apr 19 09:41:44 BST 2019
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.27.jar=9d7d7ec78ad06cd5cf7a19b2aa76568b
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=2ceaf835b625fa4c001bd2240126b69c
