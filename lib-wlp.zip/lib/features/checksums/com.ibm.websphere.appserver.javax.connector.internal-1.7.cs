#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.27.jar=2dac5b2ada74b749b3f899cf597bc648
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=3aed8d3f59e3e162dba0eb7fcb7315e5
