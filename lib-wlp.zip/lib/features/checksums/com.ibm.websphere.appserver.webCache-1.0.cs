#Fri Apr 19 09:41:44 BST 2019
lib/features/com.ibm.websphere.appserver.webCache-1.0.mf=429eb0699ba014481b8ade5abd96de34
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.webCache_1.1-javadoc.zip=9846f3f50d4b518a164b3e9aaba87708
dev/spi/ibm/com.ibm.websphere.appserver.spi.webCache_1.0.27.jar=075cb17cc124b3970a9c0e359cdeeac9
dev/api/ibm/schema/cachespec.xsd=4c363b074382cb0c1762f596c91bdfa4
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.webCache_1.0-javadoc.zip=95803122d88c9c949b4f40ae98d26a69
lib/com.ibm.ws.dynacache.web_1.0.27.jar=124ec9fd475f6c9711fbffaa141efb80
dev/api/ibm/com.ibm.websphere.appserver.api.webCache_1.1.27.jar=ad0861ea463a38792e67f95c15edd684
