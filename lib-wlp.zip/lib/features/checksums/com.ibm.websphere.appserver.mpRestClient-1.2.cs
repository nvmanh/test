#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.require.java8_1.0.27.jar=e44660b252f391906ddc6779a6d3458c
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.mp.client.3.3_1.0.27.jar=8c1e583c1a64a020a012c2ca24120e3a
lib/features/com.ibm.websphere.appserver.mpRestClient-1.2.mf=7e63ee4ab2e7ff006a1190b136cbe631
