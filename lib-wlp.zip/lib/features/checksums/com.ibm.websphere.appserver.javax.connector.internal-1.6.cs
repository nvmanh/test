#Fri Apr 19 09:41:45 BST 2019
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.27.jar=8a57f3ba7eb046dad1f1e31fea93e2e7
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=cafe174931fbc7be519a2f25cecf232a
