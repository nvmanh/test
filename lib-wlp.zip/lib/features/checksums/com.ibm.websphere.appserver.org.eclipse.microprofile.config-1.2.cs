#Fri Apr 19 09:41:44 BST 2019
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.2.1_1.0.27.jar=e6a03a5394b97ce0e5553cbbf77f48c5
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.2.mf=720dfdb9690d824b6e5aaf1af35450c0
