#Fri Apr 19 09:41:45 BST 2019
lib/com.ibm.ws.collective.utility_1.0.27.jar=87beafb035d7373daee2e9028efb2559
dev/spi/ibm/com.ibm.websphere.appserver.spi.collectiveMember_1.1.27.jar=ec132882442f24ecd3efc1a223cc9f0f
lib/com.ibm.websphere.collective.singleton_1.0.27.jar=234d132a058fb7c2dccc87bf3c418523
lib/com.ibm.ws.collective.singleton_1.0.27.jar=6ac35ded82083bea18625287fd9b560e
bin/tools/ws-collectiveutil.jar=907ad622087f165bd996d7abe5bc49b0
lib/com.ibm.ws.collective.member_1.1.27.jar=19075ef595741d3d41c403fcc9f8d08c
lib/features/com.ibm.websphere.appserver.collectiveMember-1.0.mf=200b8891ad03c511b3865c0d1837bcee
lib/com.ibm.ws.collective.repository.client_1.1.27.jar=85e91dbdfa12a6fa791eee44cff6d806
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.27.jar=12f8274e215ebae059e71fdec895c43e
lib/com.ibm.crypto.ibmkeycert_1.0.27.jar=a1c57fa3ec08e080542793ecbaec5806
lib/com.ibm.ws.collective.routing.member_1.0.27.jar=dccf79f16d806ce3c0ccb41fd1aa9b67
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.collectiveMember_1.1-javadoc.zip=fcb218a821f64654fe5a2feee608142b
lib/com.ibm.websphere.collective_1.8.27.jar=a2d1e2c5c12867a49bb4506b30ad298e
